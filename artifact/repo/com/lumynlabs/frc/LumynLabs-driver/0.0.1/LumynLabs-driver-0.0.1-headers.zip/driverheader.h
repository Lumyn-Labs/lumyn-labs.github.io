#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void c_doThing();

#ifdef __cplusplus
}  // extern "C"
#endif
