#include "header.h"
#include "driverheader.h"

void func() {
  c_doThing();
}
